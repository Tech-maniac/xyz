// Fat Arrow function :
//Fat Arrow function
const sum4=()=>{
    let a=10,b=6;
    let sum4 = a + b;
    return `The sum of 2 numbers is : ${sum4}`
}
console.log(sum4());

//Easier Way :
const sum5=()=>{
    return `The sum of 2 numbers is : ${(a=10)+(b=20)}`
}
console.log(sum5());

//If only one line of code, remove the return and curly braces
const sum6=()=> `The sum of 2 numbers is : ${(a=10)+(b=20)}`
console.log(sum6());

fruits=["apple","banana","mango"];

// For Each Loop :
fruits.forEach((element, index, array) => { 
    console.log(element);
    console.log(index);
    console.log(array);
})



// Custom API Code
//Normal Async function
async function getUsers() 
{
    let url = 'myAPI.json';
    try 
    {
        let res = await fetch(url);
        return await res.json();
    } 
    catch (error) 
    {
        console.log(error);
    }
}

async function renderUsers() 
{
    let users = await getUsers();
    let html = '';
    users.forEach(user => {
        let htmlSegment = `<div class="user">
                            <img style="width:300px; height:300px" src="${user.profileURL}" >
                            <h2>${user.firstName} ${user.lastName}</h2>
                            <div class="email"><a href="email:${user.email}">${user.email}</a></div>
                        </div>`;

        html += htmlSegment;
    });

    let container = document.querySelector('.container');
    container.innerHTML = html;
}

renderUsers();

// Random Dog Image Generator 
//Using Async Functions : 

const getImg= async()=> 
{
    let url = 'https://dog.ceo/api/breeds/image/random';
    try 
    {
        let res = await fetch(url);
        data = await res.json();
        console.log(data);
        return data;
    } 
    catch (error) 
    {
        console.log(error);
    }
}

const displayImgs=async()=>
{
    let users = await getImg();
    let html = `<div class="user">
    <img src="${users.message}" >
</div>`;
    console.log("hi");
    let container2 = document.querySelector('.container2');
    container2.innerHTML = html;
}

let btnRef = document.getElementById("btn");

btnRef.addEventListener('click',displayImgs);

// Public Holiday API :

async function getHolidays() 
{
    let url = 'https://date.nager.at/api/v2/publicholidays/2020/US';
    try 
    {
        let res = await fetch(url);
        data = await res.json();
        console.log(data);
        return data;
    } 
    catch (error) 
    {
        console.log(error);
    }
}

getHolidays();

async function displayHolidays() 
{
    let users = await getHolidays();
    let html = '';
    users.forEach(holiday => {
        let htmlSegment = `<div class="holiday">
                            <h3>Holiday Date : ${holiday.date}</h3>
                            <h3>Holiday Name : ${holiday.name}</h3>
                        </div>`;

        html += htmlSegment;
    });

    let container3 = document.querySelector('.container3');
    container3.innerHTML = html;
}

displayHolidays();


// TV Show API :

async function getTVshows() 
{
    let url = 'http://api.tvmaze.com/search/shows?q=golden%20girls';
    try 
    {
        let res = await fetch(url);
        data = await res.json();
        console.log(data);
        return data;
    } 
    catch (error) 
    {
        console.log(error);
    }
}

getTVshows();

async function displayTVshows() 
{
    let shows = await getTVshows();
    // `<h3>TV Show type : ${show[0].show.name}</h3>`
    let html = ""

    shows.forEach((showElement, index) => {  
        console.log("Element is : ");
        console.log(showElement);
        console.log(index);
        let htmlSegment = `<div class="holiday">
                            <h3>TV Show type : ${showElement.show.name}</h3>
                            <h3>TV Show Premiered On : ${showElement.show.premiered}</h3>
                        </div>`;

        html += htmlSegment;
    })

    let container4 = document.querySelector('.container4');
    container4.innerHTML = html;
}

displayTVshows();



